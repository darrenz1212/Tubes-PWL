<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-card-green leading-tight">
            {{ __('PollDet Result') }}
        </h2>
    </x-slot>
</x-app-layout>
